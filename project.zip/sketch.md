Track cost of meals , there is a huge cost on feeding all employees , imagine feeding like 400 employees. Having this data helps budgeting , assuming we have used the app for 1 week, a month , 4 months data makes sense, and helps understand the cost and allocate the cost. 


We issue employee cards which have qr code with all employe details like employee id, when card is scanned it validates if your id exists in master table(contains all current employees)