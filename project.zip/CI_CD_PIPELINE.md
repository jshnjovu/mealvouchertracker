# CI/CD Pipeline - Dev Branch

This document describes what happens each time code is pushed to the `dev` branch.

## Pipeline Flow

```
git push origin dev
        │
        ▼
┌───────────────────────────────────────────────────────┐
│              GitHub Actions Triggered                  │
│                  (deploy-dev.yml)                      │
└───────────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────────┐
│  1. CHECKOUT & SETUP                                   │
│     • Clone repository                                 │
│     • Setup Node.js 20                                 │
│     • Install dependencies (npm ci)                    │
└───────────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────────┐
│  2. QUALITY GATES                                      │
│     • Run linter (npm run lint)                        │
│     • Run tests (npm run test)                         │
│     • Build application (npm run build)                │
│     ❌ Fails here = No deployment                      │
└───────────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────────┐
│  3. GCP AUTHENTICATION                                 │
│     • Authenticate with service account key            │
│     • Configure Docker for gcr.io                      │
└───────────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────────┐
│  4. BUILD & PUSH DOCKER IMAGE                          │
│     • Build: gcr.io/converge-484513/turtle-tale-web    │
│     • Tag with commit SHA (e.g., :a706d46...)          │
│     • Push to Google Container Registry                │
└───────────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────────┐
│  5. DEPLOY TO CLOUD RUN                                │
│     • Deploy new revision to us-central1               │
│     • Zero-downtime rolling update                     │
│     • Traffic automatically shifts to new revision     │
└───────────────────────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────────────────────┐
│  ✓ APP LIVE                                            │
│    https://turtle-tale-web-cok3nafdka-uc.a.run.app     │
│    • Public access (allUsers → roles/run.invoker)      │
│    • Auto-scaling (0 to N instances)                   │
│    • HTTPS enabled by default                          │
└───────────────────────────────────────────────────────┘
```

## Key Points

| Aspect | Behavior |
|--------|----------|
| **Trigger** | Any push to `dev` branch |
| **Duration** | ~6 minutes |
| **Rollback** | Previous image versions retained in GCR |
| **Downtime** | Zero (rolling deployment) |
| **URL** | Stays the same across deployments |
| **Scaling** | Auto-scales based on traffic (including to 0) |

## Related Files

- `.github/workflows/deploy-dev.yml` - GitHub Actions workflow
- `Dockerfile` - Docker build configuration
- `next.config.mjs` - Next.js config (includes `output: 'standalone'` for Docker)
- `GCP_SETUP_GUIDE.md` - GCP service account setup instructions
