# GCP Service Account Setup Guide for GitHub Actions

This guide walks you through setting up GCP authentication for GitHub Actions CI/CD.

## Prerequisites

- Google Cloud SDK (gcloud) installed and authenticated
- GitHub CLI (gh) installed and authenticated
- Access to the GCP project: `converge-484513`

## Quick Start

Two scripts have been created to automate this process:

### Option 1: Automated Setup (Recommended)

1. **Authenticate gcloud** (if not already authenticated):
   ```bash
   gcloud auth login
   gcloud config set project converge-484513
   ```

2. **Run the setup script**:
   ```bash
   ./setup-gcp-service-account.sh
   ```
   This script will:
   - Create the service account `github-actions-deploy-dev`
   - Grant all required IAM roles
   - Generate the JSON key file

3. **Add secrets to GitHub**:
   ```bash
   ./add-github-secrets.sh
   ```
   This script will:
   - Add `GCP_PROJECT_ID_DEV` secret
   - Add `GCP_SA_KEY_DEV` secret

4. **Clean up the key file**:
   ```bash
   rm github-actions-dev-key.json
   ```

### Option 2: Manual Setup

If you prefer to run commands manually, follow these steps:

#### Step 1: Create Service Account

```bash
export PROJECT_ID="converge-484513"
export SA_NAME="github-actions-deploy-dev"

gcloud iam service-accounts create $SA_NAME \
  --display-name="GitHub Actions Deployer (Dev)" \
  --project=$PROJECT_ID
```

#### Step 2: Grant IAM Roles

```bash
export SA_EMAIL="${SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"

# Cloud Run Admin (to deploy services)
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/run.admin"

# Storage Admin (to push Docker images)
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/storage.admin"

# Service Account User (to act as Cloud Run service accounts)
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/iam.serviceAccountUser"

# Artifact Registry Admin (if using Artifact Registry)
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/artifactregistry.admin"
```

#### Step 3: Create Service Account Key

```bash
gcloud iam service-accounts keys create github-actions-dev-key.json \
  --iam-account=$SA_EMAIL \
  --project=$PROJECT_ID
```

#### Step 4: Add Secrets to GitHub

Using GitHub CLI:
```bash
# Add project ID
echo "converge-484513" | gh secret set GCP_PROJECT_ID_DEV

# Add service account key
cat github-actions-dev-key.json | gh secret set GCP_SA_KEY_DEV
```

Or manually via GitHub UI:
1. Go to: https://github.com/Malleable-ai/converge-demo/settings/secrets/actions
2. Click "New repository secret"
3. Add `GCP_PROJECT_ID_DEV` with value: `converge-484513`
4. Click "New repository secret" again
5. Add `GCP_SA_KEY_DEV` with value: (paste entire contents of `github-actions-dev-key.json`)

#### Step 5: Clean Up

```bash
rm github-actions-dev-key.json
```

## Verification

After completing the setup:

1. **Verify secrets are set** (GitHub CLI):
   ```bash
   gh secret list
   ```
   You should see both `GCP_PROJECT_ID_DEV` and `GCP_SA_KEY_DEV` in the list.

2. **Test the workflow**:
   - Push a commit to the `dev` branch, or
   - Manually trigger the workflow from the GitHub Actions tab
   - The deployment should now succeed!

## Troubleshooting

### "You do not currently have an active account selected"

Run:
```bash
gcloud auth login
gcloud config set project converge-484513
```

### "Service account already exists"

The service account may have been created previously. The setup script will continue with granting roles. If you need to recreate it, first delete the existing one:
```bash
gcloud iam service-accounts delete github-actions-deploy-dev@converge-484513.iam.gserviceaccount.com
```

### "Permission denied" errors

Ensure your GCP user account has the `roles/iam.serviceAccountAdmin` and `roles/resourcemanager.projectIamAdmin` roles, or is a project owner.

## Security Notes

- The service account key file (`github-actions-dev-key.json`) contains sensitive credentials
- **Never commit this file to version control** (it's already in `.gitignore`)
- Delete the local key file after adding it to GitHub secrets
- Rotate service account keys annually or if compromised
- Consider using Workload Identity Federation for production (more secure, no long-lived keys)

## Next Steps

Once setup is complete, your GitHub Actions workflow will automatically:
- Authenticate to GCP using the service account
- Build and push Docker images to Google Container Registry
- Deploy to Cloud Run on pushes to the `dev` branch

## Deployment Process

### How the App is Deployed

The application is automatically deployed to Google Cloud Run via GitHub Actions when code is pushed to the `dev` branch. Here's the complete deployment flow:

#### 1. **GitHub Actions Workflow** (`.github/workflows/deploy-dev.yml`)

When you push to the `dev` branch, the following steps execute automatically:

1. **Checkout & Setup**
   - Clones the repository
   - Sets up Node.js 20 and pnpm
   - Installs dependencies with `pnpm install --frozen-lockfile`

2. **Quality Gates**
   - Runs linter (`pnpm run lint`)
   - Runs tests (`pnpm run test`)
   - Builds the Next.js application (`pnpm run build`)
   - ⚠️ **If any step fails, deployment is aborted**

3. **GCP Authentication**
   - Authenticates to Google Cloud using the service account key (`GCP_SA_KEY_DEV`)
   - Configures Docker for Google Container Registry (gcr.io)

4. **Docker Image Build & Push**
   - Builds Docker image with build arguments:
     - `NEXT_PUBLIC_GCP_PROJECT_ID` (from `GCP_PROJECT_ID_DEV` secret)
     - `NEXT_PUBLIC_FIREBASE_API_KEY` (from `FIREBASE_API_KEY_DEV` secret)
     - `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` (project ID + `.appspot.com`)
     - `NEXT_PUBLIC_DISABLE_GOOGLE_SSO=true`
   - Tags image with commit SHA: `gcr.io/converge-484513/turtle-tale-web:<commit-sha>`
   - Pushes image to Google Container Registry

5. **Cloud Run Deployment**
   - Deploys new revision to Cloud Run service `turtle-tale-web`
   - Region: `us-central1`
   - Zero-downtime rolling update (traffic automatically shifts to new revision)

#### 2. **Docker Configuration**

The `Dockerfile` uses a multi-stage build:
- **Stage 1 (deps)**: Installs pnpm and dependencies
- **Stage 2 (builder)**: Builds the Next.js application with environment variables
- **Stage 3 (runner)**: Creates production image with standalone Next.js output

The Next.js config (`next.config.mjs`) includes `output: 'standalone'` which creates a minimal production bundle optimized for Docker.

#### 3. **Cloud Run Service Details**

- **Service Name**: `turtle-tale-web`
- **Region**: `us-central1`
- **Project**: `converge-484513`
- **Public URL**: `https://turtle-tale-web-cok3nafdka-uc.a.run.app`

### Accessing the Deployed Application

Once deployed, the application is accessible at:

**🌐 Production URL**: https://turtle-tale-web-cok3nafdka-uc.a.run.app

#### Service Characteristics

- **Public Access**: The service is publicly accessible (allUsers has `roles/run.invoker` permission)
- **HTTPS**: Enabled by default (Cloud Run provides SSL certificates automatically)
- **Auto-scaling**: Automatically scales from 0 to N instances based on traffic
- **Zero Downtime**: Rolling deployments ensure no service interruption
- **URL Stability**: The URL remains constant across deployments

#### Deployment Timeline

- **Typical Duration**: ~6 minutes from push to live deployment
- **Rollback**: Previous image versions are retained in GCR for quick rollback if needed
- **Monitoring**: Check deployment status in GitHub Actions or Cloud Run console

### Manual Deployment Verification

You can verify the deployment status using:

```bash
# Check Cloud Run service status
gcloud run services describe turtle-tale-web \
  --region=us-central1 \
  --project=converge-484513

# View recent revisions
gcloud run revisions list \
  --service=turtle-tale-web \
  --region=us-central1 \
  --project=converge-484513

# Check service URL
gcloud run services describe turtle-tale-web \
  --region=us-central1 \
  --project=converge-484513 \
  --format="value(status.url)"
```

### Additional GitHub Secrets Required

For the deployment to work, ensure these secrets are configured in GitHub:

- `GCP_PROJECT_ID_DEV`: `converge-484513`
- `GCP_SA_KEY_DEV`: Service account JSON key (from setup above)
- `FIREBASE_API_KEY_DEV`: Firebase API key for the dev environment

See the workflow file (`.github/workflows/deploy-dev.yml`) for the complete list of required secrets.

### Related Documentation

- **CI/CD Pipeline Details**: See `CI_CD_PIPELINE.md` for a visual flow diagram
- **Docker Configuration**: See `Dockerfile` for build details
- **Next.js Configuration**: See `next.config.mjs` for build settings
